<?php
$db_username = 'gotesgxa_adminch';
$db_password = 'adminch';
$db_name = 'gotesgxa_adminchat';
$db_host = 'localhost';
  error_reporting(E_ALL); ini_set('display_errors', 0);					
$mysqli = new mysqli($db_host, $db_username, $db_password,$db_name);						
if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}
 
define("DB_HOST", $db_host);
define("DB_NAME", $db_name);
define("DB_USER", $db_username);
define("DB_PASS", $db_password);

$con=mysqli_connect($db_host,$db_username,$db_password,$db_name);// Check connection
$conn = mysql_connect(DB_HOST, DB_USER, DB_PASS) or die(mysql_error());
$db = mysql_select_db(DB_NAME) or die(mysql_error());

		 if (mysqli_connect_errno()) 
       {
          echo "Failed to connect to MySQL: " . mysqli_connect_error();
       }
 
?>