<?php
include_once("config.php");
include_once("functions.php");
include_once("constants.php");
 
 error_reporting(E_ALL); ini_set('display_errors', 0);  
 
//check how many records are in database
$sql0 = "SELECT COUNT(*) FROM users";
$result0 = mysql_query($sql0, $conn) or die(mysql_error());
$r = mysql_fetch_row($result0);
$numrows = $r[0];
 
 
$rowsperpage = 10;
$totalpages = ceil($numrows / $rowsperpage);
 
// get the current page or set a default
if (isset($_GET['currentpage']) && is_numeric($_GET['currentpage'])) {
$currentpage = (int) $_GET['currentpage'];
} else {
$currentpage = 1;  // default page number
}
 
// if current page is greater than total pages
if ($currentpage > $totalpages) {
// set current page to last page
$currentpage = $totalpages;
}
// if current page is less than first page
if ($currentpage < 1) {
// set current page to first page
$currentpage = 1;
}
 
// the offset of the list, based on current page
$offset = ($currentpage - 1) * $rowsperpage;
 
// get the info from the MySQL database
$sql = "SELECT * FROM users where userType = 'user' ORDER BY id DESC LIMIT $offset, $rowsperpage";
$result = mysql_query($sql, $conn) or die(mysql_error());
 
while ($row = mysql_fetch_assoc($result)){
$output[]=$row;
$userId=$row["id"];
}
 
 
 

// check more records starts

$sql2 = "SELECT count(*) as more from users where userType = 'user' AND id < '".$userId."'";
$result2 = mysql_query($sql2, $conn) or die(mysql_error());
while ($row2 = mysql_fetch_assoc($result2)){
$count=$row2["more"];
}


	if(mysql_num_rows($result)>0   )   
	{
		                   $mainArr["result"] = 'success';
			               $mainArr["data"] = $output ;
			               $mainArr["message"] = 'operation success';
                           $mainArr["moreRecords"] = $count;						   
	}
    else
	{
			               $mainArr["result"] = 'failed';
			               $mainArr["data"] = [] ;
			               $mainArr["message"] = 'No User Found';	
                           $mainArr["moreRecords"] = $count;							   
	}
	
	

 

print(json_encode($mainArr));


 //http://localhost/chat/get-users.php?currentpage=2
   ?>	
